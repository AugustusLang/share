package webtest;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		String name = req.getParameter("name");
		String pass = req.getParameter("pass");
		if("ruming".equals(name) && "pass".equals(pass)){
			
			UUID uuid = UUID.randomUUID();
			String secretKey = ""+ uuid.getMostSignificantBits();
			
			resp.addCookie(new Cookie("_secretKey_"+ name, secretKey));
			req.getSession().setAttribute("_secretKey_"+ name, secretKey);
			req.getSession().setAttribute("_pin", name);
			
			req.getSession().setAttribute("_money","1000");
			
			
			//生成一个stoken做为鉴权
			UUID stoken_uuid = UUID.randomUUID();
			String stoken = ""+ stoken_uuid.getMostSignificantBits();
			req.getSession().setAttribute("_stoken", stoken);
			
			resp.sendRedirect("/home.jsp");
		}else{
			resp.sendRedirect("/");
		}
	}

}
