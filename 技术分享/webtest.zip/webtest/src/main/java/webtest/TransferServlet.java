package webtest;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String toPin = req.getParameter("toPin");
		Double money = Double.valueOf(req.getParameter("money"));
		
		String _pin = (String) req.getSession().getAttribute("_pin");
		
		String c_secretKey = "";
		Cookie[] cookies = req.getCookies();
		for (Cookie cookie : cookies) {
			if(("_secretKey_"+ _pin).equals(cookie.getName())){
				c_secretKey = cookie.getValue();
			}
		}
		String s_secretKey = (String) req.getSession().getAttribute(("_secretKey_"+ _pin));
		
		
		if((""+s_secretKey).equals(c_secretKey)){
			
			//String stoken = (String) req.getParameter("stoken");
			//String _stoken = (String) req.getSession().getAttribute("_stoken");
			//if((""+_stoken).equals(stoken)){
				
				System.out.println("鉴权成功");
				
				Double _money = Double.valueOf((String) req.getSession().getAttribute("_money"));
				
				if(( _money - money) > 0){
					_money = _money - money;
					
					req.getSession().setAttribute("_money",""+_money);
					
					System.out.println("成功给:" + toPin + "转账 " + money + " 块" );
					
					resp.sendRedirect("/home.jsp");
					return;
				}
			//}
		}
		System.out.println("转账失败" );
		resp.sendRedirect("/home.jsp");
	}
}
