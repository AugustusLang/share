package webtest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class XssServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req, resp);
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
		String say =  req.getParameter("say");
		say = new String(("" + say).getBytes("iso-8859-1"),"utf-8");
		
		List<String> list = (List<String>) req.getSession().getAttribute("list");
		if(list == null){
			list = new ArrayList<String>();
		}
		
		list.add(say);
		
		req.getSession().setAttribute("list",list);
		
		String xss =  req.getParameter("xss");
		if("xss2".equals(xss)){
			resp.sendRedirect("/xss2.jsp");
		}else if("xss3".equals(xss)){
			resp.sendRedirect("/xss3.jsp");
		}else{
			resp.sendRedirect("/xss.jsp");
		}
	}

}
