package com.jd.ads.config.dynamicDemo;

import com.jd.ads.config.client.PropertiesConfiguration;
import com.jd.ads.config.client.dynamic.prop.sources.impl.ConfigCenterConfigurationSource;
import com.jd.ads.config.client.event.ConfigurationsListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lijingjing7 on 2015/5/14.
 *
 * 模拟应用系统，此应用系统根据配置提供不同的服务
 */
public class App {

    private static final Logger logger = LoggerFactory.getLogger(App.class);
    public ConfigBean config = new ConfigBean();

    public App(){
        init();
    }

    /**
     * 初始化
     */
    public void init() {

        //启动配置中心
        /*
         * 说明：
         * DynamicXxxProperty 可以从四个地方获取配置：1.System.getProperties() 2.configCenter.properties 3.构造参数 4.配置中心
         *                                          优先级递增，意味着后面的会覆盖式获取到的配置
         */
        try {
            ConfigCenterConfigurationSource configSource = new ConfigCenterConfigurationSource();
            List<ConfigurationsListener> list = new ArrayList<ConfigurationsListener>();
            list.add(configSource);
            List<String> projCodes = new ArrayList<String>();
            projCodes.add("javademo");

            // connect to the config center
            PropertiesConfiguration config =
                    new PropertiesConfiguration("192.168.146.112:2181,192.168.146.113:2181,192.168.146.114:2181",
                            list,"test",projCodes);
        } catch (Exception e) {
            // PropertiesConfiguration初始化失败会抛出异常，由应用决定如何处理。这里是打印错误信息。
            logger.error("failed to start the config center ！！！");
        }
    }

    /**
     * 获取应用的服务
     * 1.如果on_off为0，不降级，提供服务
     * 2.如果on_off为1，降级，不提供服务
     */
    public void getService() {
        System.out.println("当前的黑词为："+config.getBlackWords());

        if (config.getOn_off() == 1) {
            System.out.println("服务被降级，暂不提供");
        } else {
            System.out.println("正常获取服务");
        }

    }

    public static void main(String[] args) throws InterruptedException {
        App app = new App();
        while(true){
            app.getService();
            Thread.sleep(2000);
        }
    }
}
