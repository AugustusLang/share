package com.jd.ads.config.dynamicDemo;

import com.jd.ads.config.client.dynamic.prop.DynamicIntProperty;
import com.jd.ads.config.client.dynamic.prop.DynamicStringProperty;

/**
 * Created by lijingjing7 on 2015/5/14.
 */
public class ConfigBean {
    private DynamicIntProperty on_off = new DynamicIntProperty("javademo","on_off",0);
    private DynamicStringProperty blackWords = new DynamicStringProperty("javademo","black_words","傻瓜,笨蛋");

    public int getOn_off() {
        return on_off.getValue();
    }

    public String getBlackWords() {
        return blackWords.getValue();
    }

}
