package com.jd.ads.config.demo;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by lijingjing7 on 2015/5/14.
 */
public class PropertiesUtil {
    private static Properties props = new Properties();
    static {
        try {
            InputStream in = PropertiesUtil.class.getResourceAsStream("/config.properties");
            props.load(in);
        } catch (IOException e) {
            //ignore
        }
    }
    public static Properties getProperties() throws IOException {
        return props;
    }
    public static String getPropertyValue(String key){
        return props.getProperty(key);
    }
}
