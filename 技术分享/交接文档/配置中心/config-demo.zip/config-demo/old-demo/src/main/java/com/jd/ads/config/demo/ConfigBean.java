package com.jd.ads.config.demo;

/**
 * Created by lijingjing7 on 2015/5/14.
 */
public class ConfigBean {
    private int on_off;
    private String blackWords;

    public int getOn_off() {
        return on_off;
    }

    public void setOn_off(int on_off) {
        this.on_off = on_off;
    }

    public String getBlackWords() {
        return blackWords;
    }

    public void setBlackWords(String blackWords) {
        this.blackWords = blackWords;
    }
}
