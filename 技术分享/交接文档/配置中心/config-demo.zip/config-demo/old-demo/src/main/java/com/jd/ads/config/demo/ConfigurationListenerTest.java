package com.jd.ads.config.demo;

import com.jd.ads.config.client.event.ConfigurationEvent;
import com.jd.ads.config.client.event.ProjcodeConfigurationListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by lijingjing7 on 2015/5/14.
 *
 * 应用服务配置中心监听器
 * 负责接收变更后的配置
 */
public class ConfigurationListenerTest implements ProjcodeConfigurationListener{

    private Logger logger = LoggerFactory.getLogger(ConfigurationListenerTest.class);
    private String projCode;
    @Override
    public String getProjCode() {
        return this.projCode;
    }

    @Override
    public void setProjCode(String projCode) {
        this.projCode = projCode;
    }

    //需要动态更改属性的bean
    private ConfigBean configBean;

    public ConfigurationListenerTest(ConfigBean config){
        this.configBean = config;
    }

    /**
     * 接收配置中心推送的配置
     * 判断是否为自己需要的配置
     * 更改内存中的配置
     * @param event
     */
    @Override
    public void configurationChanged(ConfigurationEvent event) {
        System.out.println("事件类型："+event.getType()+",工程代码："+event.getProjCode()
                +",配置名称："+event.getPropertyName()+",配置值："+event.getPropertyValue());

        if("on_off".equals(event.getPropertyName())){
            try {
                int on_off = Integer.parseInt((String) event.getPropertyValue());
                configBean.setOn_off(on_off);
            } catch (NumberFormatException e) {
                logger.error("failed to change the config ");
            }
        }


        if("black_words".equals(event.getPropertyName())){
            String blackWords = (String) event.getPropertyValue();
            configBean.setBlackWords(blackWords);
        }
    }
}
