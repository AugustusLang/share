package com.jd.ads.config.demo;

import com.jd.ads.config.client.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Created by lijingjing7 on 2015/5/14.
 *
 * 模拟应用系统，此应用系统根据配置提供不同的服务
 */
public class App {

    private static final Logger logger = LoggerFactory.getLogger(App.class);
    public ConfigBean config = new ConfigBean();

    public App(){
        init();
    }

    /**
     * 初始化
     */
    public void init() {
        //1.从本地获取所有的配置。 这里代表的是应用程序正常启动所需要做的事情！
        try {
            Properties props = PropertiesUtil.getProperties();
            int on_off = Integer.parseInt(props.getProperty("on_off"));
            String blackWords = props.getProperty("black_words");
            config.setOn_off(on_off);
            config.setBlackWords(blackWords);
        } catch (IOException e) {
            logger.error("failed to load config from local");
        }

        //2.启动配置中心，获取所有动态配置信息
        try {
            ConfigurationListenerTest listener = new ConfigurationListenerTest(config);
            listener.setProjCode("javademo");
            List list = new ArrayList();
            list.add(listener);
            PropertiesConfiguration configCenter = new PropertiesConfiguration(
                            "192.168.146.112:2181,192.168.146.113:2181,192.168.146.114:2181,192.168.146.115:2181,192.168.146.116:2181"
                            ,list
                            , "test");

            //可以从配置中心获取所有的配置，覆盖本地获取到的配置，也可以采用不覆盖的策略
            Properties props = configCenter.getProperties("javademo");
            int on_off = Integer.parseInt(props.getProperty("on_off"));
            config.setOn_off(on_off);
            String blackWords = props.getProperty("black_words");
            config.setBlackWords(blackWords);

        } catch (Exception e) {
            // 3.PropertiesConfiguration初始化失败会抛出异常，由应用决定如何处理。这里是打印错误信息。
            logger.error("failed to start the config center ！！！");
        }
    }

    /**
     * 获取应用的服务
     * 1.如果on_off为0，不降级，提供服务
     * 2.如果on_off为1，降级，不提供服务
     */
    public void getService() {
        System.out.println("当前的黑词为："+config.getBlackWords());

        if (config.getOn_off() == 1) {
            System.out.println("服务被降级，暂不提供");
        } else {
            System.out.println("正常获取服务");
        }
    }

    public static void main(String[] args) throws InterruptedException {
        App app = new App();
        while(true){
            app.getService();
            Thread.sleep(2000);
        }

    }
}
