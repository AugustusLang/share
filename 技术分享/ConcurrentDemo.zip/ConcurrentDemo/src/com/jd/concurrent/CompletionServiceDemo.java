package com.jd.concurrent;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CompletionServiceDemo implements Callable<String>{

	private String index;
	
	public CompletionServiceDemo(String index) {
		this.index = index;
	}
	
	@Override
	public String call() throws Exception {
		System.out.println(this.index + " handler................");
		Thread.sleep((int) (Math.random() * 1000));
		System.out.println(this.index + "................");
		return this.index;
	}	
	
	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(4);
		CompletionService<String> comService = new ExecutorCompletionService<String>(service);
		for (int i = 0; i < 10; i++) {
			comService.submit(new CompletionServiceDemo(String.valueOf(i)));
		}
		for (int i = 0; i < 10; i++) {
			try {
				String val = comService.take().get();
				System.out.println(val + "................");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("shut down ....");
		service.shutdown();
	}

}
