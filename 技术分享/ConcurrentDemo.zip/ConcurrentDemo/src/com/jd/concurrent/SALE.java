package com.jd.concurrent;

public enum SALE {
	INSTANCE;
	
	public String getAA(){
		return "bbbb";
	}
}

