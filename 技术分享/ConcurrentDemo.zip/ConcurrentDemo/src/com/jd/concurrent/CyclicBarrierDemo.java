package com.jd.concurrent;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CyclicBarrierDemo {
    public static void main(String[] args){    
        CyclicBarrier barrier = new CyclicBarrier(3);  
        
        ExecutorService executor = null;
        try{
	        executor = Executors.newFixedThreadPool(3);  
	        executor.submit(new Thread(new Runner(barrier, "1号选手",5000)));  
	        executor.submit(new Thread(new Runner(barrier, "2号选手",3000)));  
	        executor.submit(new Thread(new Runner(barrier, "3号选手",4000)));  
    	} catch(Exception e){
    		e.printStackTrace();
    	} finally{
    		executor.shutdown();  
    	}
        
    }  
}  
  
class Runner implements Runnable {  
    // 一个同步辅助类，它允许一组线程互相等待，直到到达某个公共屏障点 (common barrier point)  
    private CyclicBarrier barrier;  
  
    private String name; 
    
    private int prepareTime;
  
    public Runner(CyclicBarrier barrier, String name, int prepareTime) {  
        super();  
        this.barrier = barrier;  
        this.name = name;  
        this.prepareTime = prepareTime;
    }  
  
    @Override  
    public void run() {  
        try {  
            Thread.sleep(prepareTime);  
            System.out.println(String.format("%s 准备好了...", name));  
            // barrier的await方法，在所有参与者都已经在此 barrier 上调用 await 方法之前，将一直等待。  
            barrier.await();  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        } catch (BrokenBarrierException e) {  
            e.printStackTrace();  
        }  
        System.out.println(String.format("%s 起跑！", name));  
    }  
}
