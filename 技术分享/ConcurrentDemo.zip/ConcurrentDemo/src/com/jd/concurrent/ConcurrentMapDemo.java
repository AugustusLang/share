package com.jd.concurrent;

import java.text.SimpleDateFormat;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

public class ConcurrentMapDemo {

	final static SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
	
	public static void main(String[] args) {
		ConcurrentMap<String, Integer> map = 
				new ConcurrentHashMap<String, Integer>();
		map.put("aa", 1);
		map.put("bb", 2);
		map.put("cc", 3);
		map.putIfAbsent("dd", 5);
		map.putIfAbsent("cc", 6);
		map.replace("aa", 1, 7);
		map.replace("aa", 1, 8);
		map.replace("bb", 8);
		for(String key : map.keySet()){
			System.out.println(String
					.format("key: %s , value : %s", key, map.get(key)));
		}
		
		ConcurrentNavigableMap<String, Integer> navigableMap = 
				new ConcurrentSkipListMap<String, Integer>();
		navigableMap.putAll(map);
		ConcurrentNavigableMap<String, Integer> headMap = 
				navigableMap.headMap("bb");//tailMap,subMap
		for(String key : headMap.keySet()){
			System.out.println(String
					.format("navigableMap key: %s , value : %s", key, headMap.get(key)));
		}
		
	}
}
