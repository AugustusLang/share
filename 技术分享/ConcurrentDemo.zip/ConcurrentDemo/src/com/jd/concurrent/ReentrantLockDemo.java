package com.jd.concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockDemo implements Runnable{

	private MyReentrantLock lock;
	
	private int index;
	
	public ReentrantLockDemo(MyReentrantLock lock, int index) {
		this.lock = lock;
		this.index = index;
	}
	
	@Override
	public void run() {
		try{
			lock.test(index);
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(10);
		MyReentrantLock myLock = new MyReentrantLock();
		for (int i = 0; i < 10; i++) {
			service.execute(new ReentrantLockDemo(myLock, i));			
		}
		service.shutdown();
	}

}

class MyReentrantLock {
	
	private ReentrantLock lock = new ReentrantLock();
	
	public void test(int i){
		try{
			lock.lock();
			System.out.println(i+"获取锁");
			Thread.sleep((int)(Math.random()*1000));
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println(i+"释放锁");
			lock.unlock();
		}
	}
}
