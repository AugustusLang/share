package com.jd.concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorsDemo implements Runnable{

	private int index;
	
	public ExecutorsDemo(int index) {
		this.index = index;
	}
	
	@Override
	public void run() {
		try{
			System.out.println(this.index + " start..." + SALE.INSTANCE.getAA());
			Thread.sleep((int)(Math.random()*3000));
			System.out.println(this.index + " end..." + SALE.INSTANCE.getAA());
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(5);
		try{
			for (int i = 0; i < 10; i++) {
				service.execute(new ExecutorsDemo(i));//submit 返回future，检查线程是否执行完毕
			}
			//Callable
			List<Future<Integer>> futures = new ArrayList<Future<Integer>>();
			for (int i = 0; i < 10; i++) {
				final int rlt = i;
				Future<Integer> future 
					= service.submit(new Callable<Integer>() {

					@Override
					public Integer call() throws Exception {
						// TODO Auto-generated method stub
						return rlt;
					}
				});
				futures.add(future);
			}
			for(Future<Integer> future : futures){
				System.out.println(future.get());
			}			
			//invokeAll获取返回值，入参callble集合，返回future集合
			//invokeAny返回其中一个结果
		} catch(Exception e){
			e.printStackTrace();
		} finally{
			service.shutdown();
		}

	}

}
