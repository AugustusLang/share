package com.jd.concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class SemaphoreDemo extends Thread{
	
	List<String> a = new ArrayList<String>();
	
	private int index;
	
	private Semaphore semaphore;
	
	public SemaphoreDemo(int index, Semaphore semaphore) {
		this.index = index;
		this.semaphore = semaphore;
	}
	
	@Override
	public void run() {
		try{
			if(semaphore.availablePermits()>0){
				System.out.println("第" + index + "人进入厕所，有空位。");
			} else {
				System.out.println("第" + index + "人进入厕所，无空位，排队。");
			}
			semaphore.acquire();
			System.out.println("第" + index + "人获取坑位。");
			Thread.sleep((int)(Math.random()*5000));
			System.out.println("第" + index + "人使用完毕。");
			semaphore.release();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ExecutorService srevice = Executors.newFixedThreadPool(4);
		Semaphore sem = new Semaphore(2);
		for (int i = 1; i < 11; i++) {
			srevice.submit(new SemaphoreDemo(i, sem));
		}
		srevice.shutdown();
		sem.acquireUninterruptibly(2);
		System.out.println("使用完毕，该清扫了。");
		sem.release(2);
	}
}
