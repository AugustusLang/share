package com.jd.demo.springBootWeb;

import java.io.Serializable;

public class ConfigInfo implements Serializable{

	private static final long serialVersionUID = -5532198782953035813L;
	
	
	private String appName;
	private String version;
	
	
	public String getAppName() {
		return appName;
	}
	public ConfigInfo setAppName(String appName) {
		this.appName = appName;
		return this;
	}
	public String getVersion() {
		return version;
	}
	public ConfigInfo setVersion(String version) {
		this.version = version;
		return this;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appName == null) ? 0 : appName.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConfigInfo other = (ConfigInfo) obj;
		if (appName == null) {
			if (other.appName != null)
				return false;
		} else if (!appName.equals(other.appName))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ConfigInfo [appName=" + appName + ", version=" + version + "]";
	}
}
