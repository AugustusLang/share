package com.jd.demo.springBootWeb.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jd.demo.springBootWeb.ConfigInfo;
import com.jd.demo.springBootWeb.mode.Campaign;
import com.jd.demo.springBootWeb.service.CampaignService;

@RestController
@RequestMapping("/campaign")
public class CampaignController {

	@Resource
	private CampaignService campaignService;
	@Resource
	private ConfigInfo configInfo;
	
	@RequestMapping("/")
    public List<Campaign> campaigns() {
		
		System.out.println(configInfo.toString());
		
        return campaignService.getCampaigns();
    }
	
}
