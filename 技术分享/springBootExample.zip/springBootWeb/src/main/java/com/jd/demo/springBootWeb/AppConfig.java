package com.jd.demo.springBootWeb;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration 
public class AppConfig {

	
	public @Bean ConfigInfo ConfigInfo() {
		return new ConfigInfo().setAppName("SpringBoot-Web").setVersion("3.0");
	}
	
}
