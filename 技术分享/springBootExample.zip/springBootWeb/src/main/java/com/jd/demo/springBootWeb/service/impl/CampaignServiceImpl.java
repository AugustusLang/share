package com.jd.demo.springBootWeb.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jd.demo.springBootWeb.dao.CampaignDao;
import com.jd.demo.springBootWeb.mode.Campaign;
import com.jd.demo.springBootWeb.service.CampaignService;


@Service("campaignService")
public class CampaignServiceImpl implements CampaignService {

	@Resource
	private CampaignDao campaignDao;
	
	@Override
	public List<Campaign> getCampaigns() {
		return campaignDao.getCampaigns();
	}

}
