package com.jd.demo.springBootWeb.service;

import java.util.List;

import com.jd.demo.springBootWeb.mode.Campaign;



/**
 * @author zhangruming
 *
 */
public interface CampaignService {
	
	public List<Campaign> getCampaigns();

}
