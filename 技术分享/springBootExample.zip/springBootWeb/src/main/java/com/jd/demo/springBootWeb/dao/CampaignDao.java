package com.jd.demo.springBootWeb.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jd.demo.springBootWeb.mode.Campaign;

@Repository
public class CampaignDao {
	
	 @Resource
	 private JdbcTemplate jdbcTemplate;
	 
	 public List<Campaign> getCampaigns(){
		 
		String sql = "select auto_pk as autoPk,id,name,start_time as startTime,end_time as endTime,pin,status from campaign where yn =1 and pin ='sop_order' LIMIT 0,5 ";
		return jdbcTemplate.query(sql, new RowMapper<Campaign>() {
			@Override
			public Campaign mapRow(ResultSet rs, int rowNum) throws SQLException {
				Campaign campaign = new Campaign();
				campaign.setAutoPk(rs.getLong("autoPk"));
				campaign.setId(rs.getLong("id"));
				campaign.setName(rs.getString("name"));
				campaign.setStartTime(rs.getDate("startTime"));
				campaign.setEndTime(rs.getDate("endTime"));
				campaign.setPin(rs.getString("pin"));
				campaign.setStatus(rs.getInt("status"));
				return campaign;
			}
		});
	 }
	 
	
}
