package com.jd.demo.springBoot.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jd.demo.springBoot.mode.Person;

@RestController
@RequestMapping("/person")
public class PersonController {

	@RequestMapping("/")
    public List<Person> persons() {
        return Arrays.asList(new Person("zhangruming","zhangruming@jd.com"),new Person("zhangsan","zhangsan@jd.com"));
    }
	
	
	@RequestMapping("/{name}")
    public Person show(@PathVariable String name) {
        return new Person(name,name+"@jd.com");
    }
	
}
